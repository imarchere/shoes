(function(window, undefined) {

  var jimLinks = {
    "6421e6ca-be9b-490d-9007-8ced8a2cc3b0" : {
      "Menu" : [
        "db7eb83e-bcec-4430-aeb4-46274ee2c870"
      ],
      "Image_36" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "1eb85133-5bc5-4795-8322-d8e36d44d9be" : {
      "Menu" : [
        "db7eb83e-bcec-4430-aeb4-46274ee2c870"
      ]
    },
    "5fa52411-18d6-4331-b85f-b2a897fe317d" : {
      "Menu_1" : [
        "db7eb83e-bcec-4430-aeb4-46274ee2c870"
      ]
    },
    "99c1c927-2f5c-4f95-87f7-8b1553f1f4e9" : {
      "Menu" : [
        "db7eb83e-bcec-4430-aeb4-46274ee2c870"
      ]
    },
    "db7eb83e-bcec-4430-aeb4-46274ee2c870" : {
      "Tenis" : [
        "99c1c927-2f5c-4f95-87f7-8b1553f1f4e9"
      ],
      "Dama" : [
        "5fa52411-18d6-4331-b85f-b2a897fe317d"
      ],
      "Caballero" : [
        "1eb85133-5bc5-4795-8322-d8e36d44d9be"
      ],
      "Image_36" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Menu" : [
        "db7eb83e-bcec-4430-aeb4-46274ee2c870"
      ],
      "Image_1" : [
        "5fa52411-18d6-4331-b85f-b2a897fe317d"
      ],
      "Image_2" : [
        "1eb85133-5bc5-4795-8322-d8e36d44d9be"
      ],
      "Image_121" : [
        "6421e6ca-be9b-490d-9007-8ced8a2cc3b0"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);